#include <stdio.h>
#include <stdlib.h>
#define MAX 15

struct pilha{
    int qtd;
    int pilha[MAX];
};

typedef struct pilha Pilha;

Pilha* criaPilha(){
    Pilha *p = (Pilha*) malloc(sizeof(struct pilha));
    if (p != NULL)
        p->qtd = 0;

    return p;
};

int removePilha(Pilha *p){
    if(p == NULL || pilhaVazia(p) == 1)
        return 0;

    p->qtd--;
    return 1;
};

int pilhaCheia(Pilha *p){
    if(p == NULL)
        return -1;

    return (p->qtd == MAX);
}

int pilhaVazia(Pilha *p){
    if(p == NULL)
        return -1;

    return (p->qtd == 0);
}

int inserePilha(Pilha *p, int num){
    if(p == NULL || pilhaCheia(p) == 1)
        return 0;

    p->pilha[p->qtd] = num;
    p->qtd++;
    return 1;
};

int consultaPilha(Pilha *p, int nit){
    if(p == NULL || pilhaVazia(p) == 1)
        return 0;

    nit = p->pilha[p->qtd-1];
    return 1;
};

int main()
{
    int num,c,b;
    struct Pilha *p;

    criaPilha();

    inserePilha(p, num);

    int sucesso = consultaPilha(p, num);

    printf(sucesso);
};
